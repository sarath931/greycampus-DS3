CREATE TABLE students(
	
student_id  SERIAL PRIMARY KEY,
first_name varchar(10) NOT NULL,
last_name  varchar(10) NOT NULL,
homeroom_number int,
phone varchar(50) UNIQUE NOT NULL,
email varchar(200) UNIQUE NOT NULL,
graduation_year	int
)

CREATE TABLE teachers(

   teacher_id SERIAL PRIMARY KEY, 
	first_name varchar(10) NOT NULL, 
	last_name varchar(10) NOT NULL, 
	homeroom_number int , 
	department varchar(50) NOT NULL, 
	email varchar(200) UNIQUE NOT NULL, 
	phone varchar(200) UNIQUE NOT NULL
)

INSERT INTO students (student_id, first_name,last_name, homeroom_number, phone,email, graduation_year)
VALUES
(1,'Mark ' ,'Watney',5,7771251234,'' ,2035)

select * from students

INSERT INTO teachers (teacher_id, first_name,last_name, homeroom_number, department,email, phone)
VALUES
(1,'Jonas','Salk',5,'Biology','salk@school.org',777-555-4321)

select * from teachers
